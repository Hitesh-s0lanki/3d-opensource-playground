# Dioramic brand assets

Transparent logo assets for the Dioramic Next.js app.

## Main assets
- `public/brand/logo.svg` — horizontal logo + tagline
- `public/brand/logo-mark.svg` — standalone transparent mark
- `public/brand/favicon.svg` — compact favicon
- `app/icon.svg` — Next.js App Router icon
- PNG exports in `public/brand/png/`

## Example
```tsx
import Image from "next/image";

<Image src="/brand/logo.svg" alt="Dioramic" width={240} height={60} />
```
